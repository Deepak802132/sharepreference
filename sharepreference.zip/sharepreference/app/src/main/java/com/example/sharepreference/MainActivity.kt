package com.example.sharepreference


import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var editTextName: EditText
    private lateinit var editTextEmail: EditText
    private lateinit var editTextPhone: EditText
    private lateinit var imageView: ImageView
    private lateinit var sharedPreferences: SharedPreferences

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                imageView.setImageURI(it)
                imageView.visibility = ImageView.VISIBLE
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextName = findViewById(R.id.editTextName)
        editTextEmail = findViewById(R.id.editTextEmail)
        editTextPhone = findViewById(R.id.editTextPhone)
        imageView = findViewById(R.id.imageView)

        val buttonPickImage: Button = findViewById(R.id.buttonPickImage)
        val buttonSave: Button = findViewById(R.id.buttonSave)
        val buttonUpdate: Button = findViewById(R.id.buttonUpdate)
        val buttonDelete: Button = findViewById(R.id.buttonDelete)
        val buttonView: Button = findViewById(R.id.buttonView)

        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE)

        buttonPickImage.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        buttonSave.setOnClickListener {
            saveData()
        }

        buttonUpdate.setOnClickListener {
            updateData()
        }

        buttonDelete.setOnClickListener {
            deleteData()
        }

        buttonView.setOnClickListener {
            viewData()
        }

        // Load existing data if available
        loadData()
    }

    private fun saveData() {
        val name = editTextName.text.toString()
        val email = editTextEmail.text.toString()
        val phone = editTextPhone.text.toString()
        val imageBase64 = getImageBase64()

        val editor = sharedPreferences.edit()
        editor.putString("name", name)
        editor.putString("email", email)
        editor.putString("phone", phone)
        editor.putString("image", imageBase64)
        editor.apply()

        Toast.makeText(this, "Data saved successfully", Toast.LENGTH_SHORT).show()
    }

    private fun updateData() {
        val name = editTextName.text.toString()
        val email = editTextEmail.text.toString()
        val phone = editTextPhone.text.toString()
        val imageBase64 = getImageBase64()

        val editor = sharedPreferences.edit()
        editor.putString("name", name)
        editor.putString("email", email)
        editor.putString("phone", phone)
        editor.putString("image", imageBase64)
        editor.apply()

        Toast.makeText(this, "Data updated successfully", Toast.LENGTH_SHORT).show()
    }

    private fun deleteData() {
        val editor = sharedPreferences.edit()
        editor.clear() // Clears all data
        editor.apply()

        editTextName.text.clear()
        editTextEmail.text.clear()
        editTextPhone.text.clear()
        imageView.setImageDrawable(null)
        imageView.visibility = ImageView.GONE

        Toast.makeText(this, "Data deleted successfully", Toast.LENGTH_SHORT).show()
    }

    private fun loadData() {
        val name = sharedPreferences.getString("name", "")
        val email = sharedPreferences.getString("email", "")
        val phone = sharedPreferences.getString("phone", "")
        val imageBase64 = sharedPreferences.getString("image", "")

        editTextName.setText(name)
        editTextEmail.setText(email)
        editTextPhone.setText(phone)

        if (imageBase64 != null && imageBase64.isNotEmpty()) {
            val decodedString = Base64.decode(imageBase64, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
            imageView.setImageBitmap(bitmap)
            imageView.visibility = ImageView.VISIBLE
        }
    }

    private fun getImageBase64(): String {
        return imageView.drawable?.let {
            val bitmap = (it as android.graphics.drawable.BitmapDrawable).bitmap
            val byteArrayOutputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)
            Base64.encodeToString(byteArrayOutputStream.toByteArray(), Base64.DEFAULT)
        } ?: ""
    }

    private fun viewData() {
        val intent = Intent(this, DisplayActivity::class.java)
        startActivity(intent)
    }
}
